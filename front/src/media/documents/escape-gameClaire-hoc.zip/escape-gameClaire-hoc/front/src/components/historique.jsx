import React from 'react'

export default function Historique() {
  return (
    <div>historique</div>
  )
}
